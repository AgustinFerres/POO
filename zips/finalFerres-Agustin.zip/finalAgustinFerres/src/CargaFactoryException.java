public class CargaFactoryException extends Exception {

    public CargaFactoryException(String message) {
        super(message);
    }
}
