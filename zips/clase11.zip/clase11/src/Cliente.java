public class Cliente {

    private Integer cliente;

    private String  apellido;

    private String dni;

    private Integer cuit;

    public Cliente(Integer cliente, String apellido, String dni, Integer cuit) {
        this.cliente = cliente;
        this.apellido = apellido;
        this.dni = dni;
        this.cuit = cuit;
    }
}
